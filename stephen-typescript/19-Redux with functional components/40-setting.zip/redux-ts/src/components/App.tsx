const App = () => {
  return <h1>Hi!</h1>;
};

export default App;

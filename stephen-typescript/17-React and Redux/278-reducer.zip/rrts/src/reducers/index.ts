import { combineReducers } from 'redux';

export const reducers = combineReducers({
  counter: () => 1
});

export enum ActionTypes {
  fetchTodos,
  deleteTodo
}

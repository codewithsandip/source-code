import React from 'react';

export class App extends React.Component {
  render() {
    return <div>Hi there!</div>;
  }
}

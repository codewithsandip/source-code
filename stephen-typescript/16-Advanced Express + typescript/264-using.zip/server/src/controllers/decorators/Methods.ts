export enum Methods {
  get = 'get',
  post = 'post',
  patch = 'patch',
  del = 'delete',
  put = 'put'
}

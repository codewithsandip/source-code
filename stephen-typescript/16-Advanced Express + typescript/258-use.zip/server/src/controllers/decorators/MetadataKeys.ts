export enum MetadataKeys {
  method = 'method',
  path = 'path',
  middleware = 'middleware'
}

console.log('hi there');

const logSomething = () => {
  console.log('something');
};

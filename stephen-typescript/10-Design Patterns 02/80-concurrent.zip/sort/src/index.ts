console.log(123);

const logSomething = () => {
  console.log('something');
};
logSomething();

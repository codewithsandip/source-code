const HtmlRspackPlugin = require("@rspack/plugin-html");
const ModuleFederationPlugin = require("@rspack/plugin-module-federation");

module.exports = {
  context: __dirname,
  entry: "./src/index.tsx",
  mode: "development",
  devServer: {
    port: 4001,
    open: false,
  },
  output: { publicPath: "auto" },
  resolve: { extensions: [".ts", ".tsx", ".js"] },
  module: {
    rules: [{ test: /\.tsx?$/, use: "ts-loader", exclude: /node_modules/ }],
  },
  plugins: [
    new ModuleFederationPlugin({
      name: "remote",
      filename: "remoteEntry.js",
      exposes: { "./RemoteApp": "./src/App" },
      shared: {
        react: { singleton: true, eager: false, requiredVersion: false },
        "react-dom": { singleton: true, eager: false, requiredVersion: false },
      },
    }),
    new HtmlRspackPlugin({ template: "./public/index.html" }),
  ],
};
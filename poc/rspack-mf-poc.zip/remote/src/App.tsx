import React from "react";

export default function RemoteApp() {
  return (
    <div style={{ padding: 20, border: "2px solid #2b6cb0" }}>
      <h2>Remote App (Rspack Module Federation)</h2>
      <p>This component is exposed by the remote and loaded by the shell at runtime.</p>
    </div>
  );
}
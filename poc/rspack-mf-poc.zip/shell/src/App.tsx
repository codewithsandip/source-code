import React, { Suspense } from "react";

const RemoteApp = React.lazy(() => import("remote/RemoteApp"));

export default function App() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Shell App (Rspack Module Federation)</h1>
      <Suspense fallback={<div>Loading remote...</div>}>
        <RemoteApp />
      </Suspense>
    </div>
  );
}
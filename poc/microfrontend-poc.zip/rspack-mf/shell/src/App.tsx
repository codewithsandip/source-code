import React from 'react';
export default function App() {
  return <div style={padding: 10, border: '1px solid gray'}>
    <h3>Shell App (Rspack MF)</h3>
  </div>;
}
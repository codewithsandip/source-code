const HtmlRspackPlugin = require("@rspack/plugin-html");
const ModuleFederationPlugin = require("@rspack/plugin-module-federation");

module.exports = {
  entry: "./src/index.tsx",
  mode: "development",
  devServer: { port: 4000 },
  plugins: [

new ModuleFederationPlugin({
  name: "shell",
  remotes: {
    dashboard: "dashboard@http://localhost:4001/remoteEntry.js",
    settings: "settings@http://localhost:4002/remoteEntry.js",
  },
  shared: { react: { singleton: true }, "react-dom": { singleton: true } },
}),

    new HtmlRspackPlugin({ template: "./public/index.html" }),
  ],
};
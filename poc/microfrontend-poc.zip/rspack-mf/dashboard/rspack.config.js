const HtmlRspackPlugin = require("@rspack/plugin-html");
const ModuleFederationPlugin = require("@rspack/plugin-module-federation");

module.exports = {
  entry: "./src/index.tsx",
  mode: "development",
  devServer: { port: 4001 },
  plugins: [

new ModuleFederationPlugin({
  name: "dashboard",
  filename: "remoteEntry.js",
  exposes: { "./DashboardApp": "./src/App" },
  shared: { react: { singleton: true }, "react-dom": { singleton: true } },
}),

    new HtmlRspackPlugin({ template: "./public/index.html" }),
  ],
};
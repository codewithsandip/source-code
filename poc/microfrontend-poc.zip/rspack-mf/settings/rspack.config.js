const HtmlRspackPlugin = require("@rspack/plugin-html");
const ModuleFederationPlugin = require("@rspack/plugin-module-federation");

module.exports = {
  entry: "./src/index.tsx",
  mode: "development",
  devServer: { port: 4002 },
  plugins: [

new ModuleFederationPlugin({
  name: "settings",
  filename: "remoteEntry.js",
  exposes: { "./SettingsApp": "./src/App" },
  shared: { react: { singleton: true }, "react-dom": { singleton: true } },
}),

    new HtmlRspackPlugin({ template: "./public/index.html" }),
  ],
};
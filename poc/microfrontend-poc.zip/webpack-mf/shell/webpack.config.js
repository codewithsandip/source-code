const HtmlWebpackPlugin = require("html-webpack-plugin");
const ModuleFederationPlugin = require("webpack/lib/container/ModuleFederationPlugin");

module.exports = {
  mode: "development",
  devServer: { port: 3000 },
  output: { publicPath: "auto" },
  module: {
    rules: [{ test: /\.tsx?$/, loader: "ts-loader" }]
  },
  resolve: { extensions: [".tsx", ".ts", ".js"] },
  plugins: [

new ModuleFederationPlugin({
  name: "shell",
  remotes: {
    dashboard: "dashboard@http://localhost:3001/remoteEntry.js",
    settings: "settings@http://localhost:3002/remoteEntry.js",
  },
  shared: { react: { singleton: true }, "react-dom": { singleton: true } },
}),

    new HtmlWebpackPlugin({ template: "./public/index.html" }),
  ],
};
import React from 'react';
export default function App() {
  return <div style={padding: 10, border: '1px solid gray'}>
    <h3>Settings App (Webpack MF)</h3>
  </div>;
}
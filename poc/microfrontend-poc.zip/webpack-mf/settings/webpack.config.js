const HtmlWebpackPlugin = require("html-webpack-plugin");
const ModuleFederationPlugin = require("webpack/lib/container/ModuleFederationPlugin");

module.exports = {
  mode: "development",
  devServer: { port: 3002 },
  output: { publicPath: "auto" },
  module: {
    rules: [{ test: /\.tsx?$/, loader: "ts-loader" }]
  },
  resolve: { extensions: [".tsx", ".ts", ".js"] },
  plugins: [

new ModuleFederationPlugin({
  name: "settings",
  filename: "remoteEntry.js",
  exposes: { "./SettingsApp": "./src/App" },
  shared: { react: { singleton: true }, "react-dom": { singleton: true } },
}),

    new HtmlWebpackPlugin({ template: "./public/index.html" }),
  ],
};
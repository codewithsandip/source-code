const HtmlWebpackPlugin = require("html-webpack-plugin");
const ModuleFederationPlugin = require("webpack/lib/container/ModuleFederationPlugin");

module.exports = {
  mode: "development",
  devServer: { port: 3001 },
  output: { publicPath: "auto" },
  module: {
    rules: [{ test: /\.tsx?$/, loader: "ts-loader" }]
  },
  resolve: { extensions: [".tsx", ".ts", ".js"] },
  plugins: [

new ModuleFederationPlugin({
  name: "dashboard",
  filename: "remoteEntry.js",
  exposes: { "./DashboardApp": "./src/App" },
  shared: { react: { singleton: true }, "react-dom": { singleton: true } },
}),

    new HtmlWebpackPlugin({ template: "./public/index.html" }),
  ],
};